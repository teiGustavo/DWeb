<?php
    if (!isset($_SESSION)){
        session_start();
    }

    if($_SESSION["logado"] == 0){
        header("location: ../../index.php");
    }
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../css/index.css">
    <title>Cardápio</title>
</head>
<body onload="pagCardapio()">
    <?php
        include "../apoio/navbar.php";
    ?>

    <?php
        include "../../conexao.php";
        include "../../SQL.php";

        $sql = "SELECT * FROM cardapio WHERE data >= CURRENT_DATE";
        $resultado = mysqli_query($conexao, $sql);

        while($linha=mysqli_fetch_array($resultado)){
            echo "<div class='item'>";
                echo "<h4>".$linha["diasemana"]."</h4>";
                echo "<p>".$linha["cardapio"]."</p>";
                echo "<a href='detalhe.php?id=".$linha["idcardapio"]."'>Ver mais</a>";

                if ($_SESSION["logado_adm"] != 1) {
                    echo "<div class = 'avl'>";
                        echo "<ul class='avaliacao'>";
                            echo "<li class='star-icon ativo' data-avaliacao='1'></li>";
                            echo "<li class='star-icon' data-avaliacao='2'></li>";
                            echo "<li class='star-icon' data-avaliacao='3'></li>";
                            echo "<li class='star-icon' data-avaliacao='4'></li>";
                            echo "<li class='star-icon' data-avaliacao='5'></li>";
                        echo "</ul>";
                    echo "</div>";
                } else {
                    echo "<div class = 'avl'>";
                        echo "<form method='POST' action='../adm/adm_cardapio.php'>";    
                            echo "<select name='ID' style='display: none;'>";
                                echo "<option value=" . $linha["idcardapio"] . "></option>";
                            echo "</select>";
                            echo "<button type='submit' name='btn-admCardapio'><img src='../../css/img/edit.svg'></button>";
                        echo "</form>";
                    echo "</div>";
                }

            echo "</div>";
        }
    ?>
    
</body>

    <script src="../../js/funcoes.js"></script>

</html>