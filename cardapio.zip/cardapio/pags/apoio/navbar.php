<?php
    include "../../conexao.php";
    $logoff = "../apoio/logoff.php";

    if ($_SESSION["logado_adm"] == 1) {
        echo "<div class='nvb'>";
            echo "<nav class='navbar' id='navbar'>";
                echo "<a href='../adm/adm.php' class='logo'>STAFF</a>";
                echo "<div class='nav-links' id='nav-links'>";
                    echo "<ul>";
                        echo "<li id='li-one'><a href='../cadastro/cadastro.php'>Cadastro de Aluno</a></li>";
                        echo "<li id='li-two'><a href='../adm/adm_inserir.php'>Cadastrar Dados</a></li>";;
                        echo "<li id='li-three'><a href='../adm/adm_consultar.php'>Consultar Dados</a></li>";
                        echo "<li id='li-four'><a href='../adm/adm_cardapio.php'>Alterar Dados</a></li>";
                        echo "<li id='li-five'><a href='../cardapio/cardapio.php'>Cardapios</a></li>";
                        echo "<li><a href='$logoff'>Sair</a></li>";
                        echo "";
                    echo "</ul>";
                echo "</div>";
                echo "<button type='button' onclick='apareceMenu()' id='btn-btn-menu' class='btn-btn-menu'><img src='styles/img/menu.svg' alt='menu' class='btn-menu'></button>";
            echo "</nav>";
        echo "</div>";
    } else {
        echo "<div class='nvb'>";
            echo "<nav class='navbar' id='navbar'>";
                echo "<a href='../cardapio/cardapio.php' class='logo'>CARDÁPIO</a>";
                echo "<div class='nav-links' id='nav-links'>";
                    echo "<ul>";
                        echo "<li class='active' id='li-one'><a href='../cardapio/cardapio.php'>Home</a></li>";
                        echo "<li><a href='$logoff'>Sair</a></li>";
                    echo "</ul>";
                echo "</div>";
                echo "<button type='button' onclick='apareceMenu()' id='btn-btn-menu' class='btn-btn-menu'><img src='styles/img/menu.svg' alt='menu' class='btn-menu'></button>";
            echo "</nav>";
        echo "</div>";
    }
?> 
