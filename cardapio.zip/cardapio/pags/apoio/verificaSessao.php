<?php
     if (!isset($_SESSION)){
        session_start();
    }
    
    if (!isset($_SESSION["logado"])){
        $_SESSION["logado"] = 0;
    }
    
    if (!isset($_SESSION["logado_adm"])){
        $_SESSION["logado_adm"] = 0;
    }
?>