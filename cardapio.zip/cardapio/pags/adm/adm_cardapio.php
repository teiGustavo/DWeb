<?php
    include "../../conexao.php";
    include "../../SQL.php";
    include "../apoio/verificaSessao.php";

    if($_SESSION["logado_adm"] == 0)
        header("location: login-adm.php");
    
    $SQL = new SQL();

    if (!isset($_SESSION["ID"]) || $_SESSION["ID"] == null) {
        if (isset($_POST["btn-admCardapio"])) 
            $_SESSION["ID"] = $_POST["ID"];
        else
            header("location: adm_selecionaCardapio.php");
    }
?>

<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="../../css/index.css">
        <title>Staff Excluir</title>
    </head>
    <body>

        <div class="main-login">
            <form method="POST"> 
                <div class="right-login" id="right-login">
                    <div class="card-login"id="card-1">
                        <h1 style="color: white; margin-bottom: 35px;">O QUE DESEJA FAZER?</h1>
                        <p style="color: white; margin-top: -20px; margin-bottom: 20px;">ID CARDÁPIO: <?php echo $_SESSION['ID']; ?></p>
                        <button type="button" class="btn-login" name="btn-alterarCardapio" onclick="btnAlterar()">Alterar Cardapio</button>
                        <button type="button" class="btn-login" name="btn-excluirCardapio" onclick="btnExcluir()">Excluir Cardapio</button>
                        <button type="submit" class="btn-login" name="btn-retornar">Retornar</button>
                    </div>
                    <div class="card-login" id="card-2" style="display: none;">
                        <h1 style="color: red; margin-bottom: 35px;">CONFIRMAR EXCLUSÃO?</h1>
                        <button type="submit" class="btn-login" name="btn-sim">SIM</button>
                        <button type="submit" class="btn-login" name="btn-nao">NÃO</button>
                    </div>
                    <div class="card-login" id="card-3" style="display: none;">
                        <h1 style="color: white; margin-bottom: 35px;">ALTERAR DADOS</h1>
                        <?php
                            $nomeColunas = $SQL->selecNomeColunas("Cardapio");
                            $valores = $SQL->selectAllWhere("Cardapio", $_SESSION["ID"]);

                            $dia = $valores["diasemana"];

                            echo "<div class='textfield'>";
                                echo "<label for='id'>ID Cardapio</label>";
                                echo "<input type='number' name='idr' placeholder='ID do cardápio' value=" . $valores["idcardapio"] . " style='cursor: no-drop;' disabled>";
                                echo "<input type='number' name='id' placeholder='ID do cardápio' value=" . $valores["idcardapio"] . " style='display: none;'>";
                                echo "</div>";

                            echo "<div class='textfield'>";
                                echo "<label for='data'>Data</label>";
                                echo "<input type='date' name='data' placeholder='Data do cardápio' id='data' value=" . $valores["data"] . " onchange='diaSemana()' onclick='diaSemana()'>";
                            echo "</div>"; 

                            echo "<div class='textfield'>";
                                echo "<label for='dia'>Dia da semana</label>";
                                echo "<input type='text' name='diar' placeholder='Dia da semana' id='dia' value=" . $dia . " style='cursor: no-drop;' disabled>";
                                echo "<input type='text' name='dia' placeholder='Dia da semana' id='diaV' value=" . $dia . " style='display: none;'>";
                            echo "</div>";
                            
                            echo "<div class='textfield'>";
                                echo "<label for='cardapio'>Cardapio</label>";
                                echo "<input type='text' name='cardapio' placeholder='Cardapio' value=" . '"' . $valores["cardapio"] . '"' . ">";
                            echo "</div>"; 

                            echo "<div class='textfield'>";
                                echo "<label for='obs'>Observação</label>";
                                echo "<input type='text' name='obs' placeholder='Observação' value=" . '"' .  $valores["observacao"] . '"' . ">";
                            echo "</div>";

                            echo "<div class='textfield'>";
                                echo "<label for='curtida'>Total de curtidas</label>";
                                echo "<input type='number' name='curtida' placeholder='Total de curtidas' value=" . $valores["totalcurtida"] . ">";
                            echo "</div>";
                        ?>
                    <button type="submit" class="btn-login" name="btn-atualizar" onclick="fecharJanela()">Atualizar</button>
                    <!--button type="submit" class="btn-login" name="btn-return">RETORNAR</button-->
                    </div>
                </div>
            </form>
        </div>

        <?php
            if(isset($_POST["btn-retornar"]))
                header("location: ../cardapio/cardapio.php");

            if (isset($_POST["btn-sim"])) {
                $SQL->deleteCardapio($_SESSION["ID"]);
                $_SESSION["ID"] = null;
                header("location: ../cardapio/cardapio.php");
            }

            if (isset($_POST["btn-atualizar"])) {
                $id = $_POST["id"];
                $data = $_POST["data"];
                $dia = $_POST["dia"];
                $cardapio = $_POST["cardapio"];
                $observacao = $_POST["obs"];
                $totalcurtida = $_POST["curtida"];
                $SQL->updateCardapio($id, $data, $dia, $cardapio, $observacao, $totalcurtida);
                $_SESSION["ID"] = null;
                header("location: ../cardapio/cardapio.php");
            }
        ?>

    </body>

    <script src="../../js/jquery/dist/jquery.min.js"></script>
    <script src="../../js/funcoes.js"></script>

</html>
