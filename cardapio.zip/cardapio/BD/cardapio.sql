DROP DATABASE IF EXISTS CARDAPIO;
CREATE DATABASE IF NOT EXISTS cardapio;
USE cardapio;
SET GLOBAL lc_time_names=pt_BR;
SET lc_time_names=pt_BR;

CREATE TABLE IF NOT EXISTS administrador(
	email VARCHAR(100),
    foto VARCHAR(100),
	id_admin INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(100),
    senha VARCHAR(32)
);

CREATE TABLE IF NOT EXISTS curso(
    idcurso INT NOT NULL AUTO_INCREMENT,
    curso VARCHAR(45),
    CONSTRAINT pkcurso PRIMARY KEY (idcurso));
    
CREATE TABLE IF NOT EXISTS aluno(
	adm TINYINT DEFAULT 0,
    apelido VARCHAR(45),
    curso_idcurso INT NOT NULL,
    email VARCHAR(100),
    foto VARCHAR(100),
	idaluno INT NOT NULL AUTO_INCREMENT,
    nome VARCHAR(100),
    senha VARCHAR(32),
    CONSTRAINT pkaluno PRIMARY KEY (idaluno),
    CONSTRAINT fkalunocurso FOREIGN KEY (curso_idcurso) REFERENCES curso(idcurso));
    
CREATE TABLE IF NOT EXISTS cardapio(
	cardapio VARCHAR(500),
    data DATE,
    diasemana VARCHAR(45),
	idcardapio INT NOT NULL AUTO_INCREMENT,
    observacao VARCHAR(255),
	totalcurtida INT DEFAULT 0,
    CONSTRAINT pkcardapio PRIMARY KEY (idcardapio));
    
CREATE TABLE IF NOT EXISTS curtida(
	aluno_idaluno INT NOT NULL,
    cardapio_idcardapio INT NOT NULL,
	idcurtida INT NOT NULL AUTO_INCREMENT,
    CONSTRAINT pkcurtida PRIMARY KEY (idcurtida),
    CONSTRAINT fkcurtidacardapio FOREIGN KEY (cardapio_idcardapio) REFERENCES cardapio(idcardapio),
    CONSTRAINT fkcurtidaaluno FOREIGN KEY (aluno_idaluno) REFERENCES aluno(idaluno));
    
CREATE TABLE IF NOT EXISTS comentario(
	aluno_idaluno INT NOT NULL,
    cardapio_idcardapio INT NOT NULL,  
    comentario VARCHAR(100),
	idcomentario INT NOT NULL AUTO_INCREMENT,
    CONSTRAINT pkcomentario PRIMARY KEY (idcomentario),
    CONSTRAINT fkcomentariocardapio FOREIGN KEY (cardapio_idcardapio) REFERENCES cardapio(idcardapio),
    CONSTRAINT fkcomentarioaluno FOREIGN KEY (aluno_idaluno) REFERENCES aluno(idaluno));
    
CREATE TABLE IF NOT EXISTS avaliacao(
	data_avaliacao DATETIME,
	id_avaliacao INT NOT NULL PRIMARY KEY,
	qtd_estrela INT NOT NULL,
    qtd_votos INT NOT NULL
);

INSERT INTO ADMINISTRADOR(NOME, EMAIL, SENHA) VALUES
('Gustavo Teixeira', 'adm@adm.com', 'adm');

INSERT INTO CARDAPIO(DATA, DIASEMANA, CARDAPIO, OBSERVACAO) VALUES
('2022-12-30', 'Sexta-Feira', 'Arroz, feijao, batata e salada', 'Opçoes veganas disponiveis!');

INSERT INTO CURSO(CURSO) VALUES
('AGROECOLOGIA'),
('ELETROTECNICA'),
('INFORMATICA'),
('MECANICA'),
('MEIO AMBIENTE');

INSERT INTO ALUNO(NOME, EMAIL, SENHA, APELIDO, CURSO_IDCURSO) VALUES
('Gustavo', 'gugu@hotmail.com', md5('12345678'), 'Gugu', 1),
('a', 'a@a.a', md5('a'), 'a', 1);