<?php

    if ($_SESSION["logado_adm"] == 1) {
        echo "<nav class='menu'>";
            echo "<span class='link'>";
                echo "<a href='../cardapio/cardapio.php'>Principal</a>";
            echo "</span>";
            echo "<span class='link'>";
                echo "<a href='../cadastro/cadastro.php'>Cadastro de aluno</a>";
            echo "</span>";
            echo "<span class='link'>";
                echo "<a href='../adm/adm_inserir.php'>Cadastro de curso</a>";
            echo "</span>";
            echo "<span class='link'>";
                echo "<a href='../adm/adm_inserir.php'>Cadastro de cardapio</a>";
            echo "</span>";
            echo "<span class='linkFim'>";
                echo "<a href='../apoio/logoff.php'>Sair</a>";
            echo "</span>";
        echo "</nav>";
    } else {
        echo "<nav class='menu'>";
            echo "<span class='link'>";
                echo "<a href='../cardapio/cardapio.php'>Principal</a>";
            echo "</span>";
            echo "<span class='linkFim'>";
                echo "<a href='../apoio/logoff.php'>Sair</a>";
            echo "</span>";
        echo "</nav>";
    }

?>
