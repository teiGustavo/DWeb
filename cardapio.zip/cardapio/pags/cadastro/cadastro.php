<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="../../css/index.css">
        <title>Cadastro</title>
    </head>
    <body>
        <div class="main-login">
            <div class="left-login">
                <h1>Olá novato<br>Insira seus dados abaixo</h1>
                <img src="../../css/img/lunch-time-animate.svg" class="left-login-image" alt="Astronauta animação">
            </div>

            <form method="POST">
                <div class="right-login">
                    <div class="card-login">
                        <h1>CADASTRO</h1>
                            <div class="textfield">
                                <label for="nome">Nome</label>
                                <input type="text" name="nome" placeholder="Nome">
                            </div>
                            <div class="textfield">
                                <label for="apelido">Apelido</label>
                                <input type="text" name="apelido" placeholder="Apelido">
                            </div>
                            <div class="textfield">
                                <label for="curso">Curso</label>
                                <select class="combobox" id="combobox_curso" name="curso">
                                    <option>Selecione seu curso</option>
                                    <?php
                                        require_once "../../SQL.php";

                                        $SQL = new SQL();
                                        $cursos = $SQL->selectCursos();

                                        for ($i=0; $i<count($cursos); $i++) 
                                            echo "<option value=" . $cursos[$i][0] . ">" . ucfirst(strtolower($cursos[$i][1])) . "</option>";                            
                                        
                                    ?>
                                </select>
                            </div>
                            <div class="textfield">
                                <label for="email">Email</label>
                                <input type="email" name="email" placeholder="Email">
                            </div>
                            <div class="textfield">
                                <label for="usuario">Senha</label>
                                <input type="password" name="senha" placeholder="Senha">
                            </div>
                            <button type="submit" class="btn-login" name="btn-cadastro">Login</button>
                        <a href="../../index.php">Já possui conta? Faça seu login</a>
                    </div>   
                </div>
            </form>

            <?php
                include "../../conexao.php";

                if(isset($_POST["btn-cadastro"])){
                    $nome = $_POST["nome"];
                    $apelido = $_POST["apelido"];
                    $curso = $_POST["curso"];
                    $email = $_POST["email"];
                    $senha = md5($_POST["senha"]);

                    $SQL->insertAluno($nome, $apelido, $curso, $email, $senha);

                    header("location: ../../index.php");
                }
            ?>

        </div>
    </body>
</html>