<?php
    if (!isset($_SESSION)){
        session_start();
    }

    if ($_SESSION["logado_adm"] == 1){
        header("location: adm.php");
    } 

?>

<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="../../css/index.css">
        <title>Login ADM</title>
    </head>
    <body>
        <div class="main-login">
            <div class="left-login">
                <h1>Olá administrador,<br>Seja bem vindo!</h1>
                <img src="../../css/img/admin-animate.svg" class="left-login-image" alt="Astronauta animação">
            </div>

            <form method="POST">
                <div class="right-login">
                    <div class="card-login">
                        <h1>LOGIN STAFF</h1>
                        <div class="textfield">
                            <label for="email">Email</label>
                            <input type="email" name="email" placeholder="Email">
                        </div>
                        <div class="textfield">
                            <label for="usuario">Senha</label>
                            <input type="password" name="senha" placeholder="Senha">
                        </div>
                        <button type="submit" class="btn-login" name="btn-login">Login</button>
                        <br><a href="../../index.php">Está aqui por engano? Página para alunos aqui!</a>

                        <?php
                            require_once "../../SQL.php";

                            $SQL = new SQL();

                            if(isset($_POST["btn-login"])){
                                $email = $_POST["email"];
                                $senha = $_POST["senha"];

                                if ($SQL->authenticateAdm($email, $senha))
                                    header("location: adm.php");
                                else
                                    echo "<br>Email e/ou senha incorretos!";
                                
                            }
                        ?>

                    </div>
                </div>
            </form>

        </div>
    </body>
</html>