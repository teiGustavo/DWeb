var stars = document.querySelectorAll('.star-icon');
var main_login = document.querySelector('#main-login');
var left_login = document.querySelector('#left-login');
var right_login = document.querySelector('#right-login');
var navbar = document.querySelector('#navbar');
                  
document.addEventListener('click', function(e){
  var classStar = e.target.classList;

    if(!classStar.contains('ativo')){
        stars.forEach(function(star){
            star.classList.remove('ativo');
        });

        classStar.add('ativo');
        console.log(e.target.getAttribute('data-avaliacao'));
    }

});

function pagAdm() {
    main_login.style.height = '90vh';
    left_login.style.height = '90vh';
    right_login.style.height = '90vh';
    navbar.style.margin = '50px';
}

function pagAdmConsultar() {
    main_login.style.height = '90vh';
    left_login.style.height = '90vh';
    right_login.style.height = '90vh';
    navbar.style.margin = '50px';

    var li_three = document.querySelector('#li-three');
    li_three.classList.add('active');
}

function pagCardapio() {
    navbar.style.margin = '50px';

    var li_five = document.querySelector('#li-five');
    li_five.classList.add('active');
}

function btnExcluir() {
    var card_1 = document.querySelector('#card-1');
    var card_2 = document.querySelector('#card-2');
    var card_3 = document.querySelector('#card-3');

    card_1.style.display = 'none';
    card_3.style.display = 'none';
    card_2.style.display = 'flex';
}

function btnAlterar() {
    var card_1 = document.querySelector('#card-1');
    var card_2 = document.querySelector('#card-2');
    var card_3 = document.querySelector('#card-3');

    card_1.style.display = 'none';
    card_2.style.display = 'none';
    card_3.style.display = 'flex';
}

function diaSemana() {
    var textData = $('#data').val();
    var data = new Date(textData);
    var diaDaSemana = ((data.getDay()) + 1);

    switch (diaDaSemana) {
        case 0:
            diaDaSemana = "Domingo";
            break;
        case 1:
            diaDaSemana = "Segunda-Feira";
            break;
        case 2:
            diaDaSemana = "Terça-Feira";
            break;
        case 3:
            diaDaSemana = "Quarta-Feira";
            break;
        case 4:
            diaDaSemana = "Quinta-Feira";
            break;
        case 5:
            diaDaSemana = "Sexta-Feira";
            break;
        case 6:
            diaDaSemana = "Sábado";
            break;
        case 7:
            diaDaSemana = "Domingo";
            break;
    }

    $('#dia').val(diaDaSemana);
    $('#diaV').val(diaDaSemana);
}

function fecharJanela() {
    //window.close();
}

function listar() {
    var card_1 = document.querySelector('#card-1');
    card_1.style.display = 'none';
}

function checkboxPress() {
    var btn_ok = document.querySelector('#btn-ok');
    btn_ok.style.cursor = "pointer";
    btn_ok.removeAttribute("disabled");
}

function pagSeleciona() {
    main_login.style.height = '95vh';
}