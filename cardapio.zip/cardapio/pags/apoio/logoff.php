<?php
    session_start();

    $_SESSION["logado"] = 0;
    $_SESSION["logado_adm"] = 0;
    $_SESSION["ID_aluno"] = null;

    header("location: ../../index.php");
?>