<?php

    include "../../conexao.php";

    if (!isset($_SESSION)){
        session_start();
    }
    
?>

<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="../../css/index.css">
        <title>Esqueci a senha</title>
    </head>
    <body>
        <div class="main-login">
            <div class="left-login">
                <h1>Defina sua senha abaixo<br>e fique contente!</h1>
                <img src="../../css/img/lunch-time-animate.svg" class="left-login-image" alt="Astronauta animação">
            </div>

            <form method="POST">
                <div class="right-login" id="esqueceu-login">
                    <div class="card-login">
                        <h1>INSIRA SUA NOVA SENHA</h1>
                            <div class="textfield">
                                <label for="senha">Senha</label>
                                <input type="password" name="senha" placeholder="Senha">
                            </div>
                            <button type="submit" class="btn-login" name="btn-cadastro" id="btn-cadastro">Alterar</button>
                        <a href="../../index.php">Já possui conta? Faça seu login</a>
                    </div>   
                </div>
            </form>

            <?php

                if(isset($_POST["btn-cadastro"])){
    
                    $id = $_SESSION["id_aluno"];
                    $senha = $_POST["senha"];
                    
                    $sql = "UPDATE ALUNO SET SENHA = '$senha' WHERE IDALUNO = '$id'";
                    $resultado = mysqli_query($conexao, $sql);
                    
                    header("location: ../../index.php");
                }
            ?>

        </div>
    </body>

    <script src="../../js/jquery/dist/jquery.min.js"></script>
    <script src="../../js/funcoes.js"></script>
    
</html>