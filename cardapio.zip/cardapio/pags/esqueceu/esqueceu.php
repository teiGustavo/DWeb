<?php

    include "../../conexao.php";

    if (!isset($_SESSION)){
        session_start();
    }
    
?>

<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="../../css/index.css">
        <title>Esqueci a senha</title>
    </head>
    <body>
        <div class="main-login">
            <div class="left-login">
                <h1>Olá veterano<br>Insira seus dados abaixo</h1>
                <img src="../../css/img/lunch-time-animate.svg" class="left-login-image" alt="Astronauta animação">
            </div>

            <form method="POST">
                <div class="right-login" id="esqueceu-login">
                    <div class="card-login">
                        <h1>ESQUECEU A SENHA</h1>
                            <div class="textfield">
                                <label for="email">Email</label>
                                <input type="email" name="email" placeholder="Email">
                            </div>
                            <button type="submit" class="btn-login" name="btn-cadastro" id="btn-cadastro">Procurar</button>
                        <a href="../../index.php">Já possui conta? Faça seu login</a>
                    
                        <?php

                            if(isset($_POST["btn-cadastro"])){
                                $email = $_POST["email"];
                                
                                $sql = "SELECT * FROM ALUNO WHERE EMAIL = '$email'";
                                $resultado = mysqli_query($conexao, $sql);

                                if (mysqli_num_rows($resultado) >= 1) {
                                    $id = mysqli_fetch_array($resultado);
                                    $_SESSION["id_aluno"] = $id["idaluno"];
                                    header("location: esqueceu2.php");
                                } else {
                                    echo "Email não encontrado!";
                                }
                            }
                        ?>

                    </div>   
                </div>
            </form> 
        </div>
    </body>

    <script src="../../js/jquery/dist/jquery.min.js"></script>
    <script src="../../js/funcoes.js"></script>
    
</html>