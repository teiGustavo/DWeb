<?php
    include "../../conexao.php";
    include "../apoio/verificaSessao.php";

    if (isset($_POST["btComentar"])) {
        $id = $_POST["ID"];
        $comentario = $_POST["txtcomentario"];
        $ID_aluno = $_SESSION["ID_aluno"];

        $sql = "INSERT INTO comentario(cardapio_idcardapio, aluno_idaluno, comentario) VALUES ($id, $ID_aluno, '$comentario')";
        mysqli_query($conexao, $sql);

        header("location: detalhe.php?id=$id");
    }

?>