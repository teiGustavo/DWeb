<?php

class SQL 
{
    
    public $conexao;
    public $bd;

    public function connect() 
    {
        $servidor = "localhost";
        $usuario = "root";
        $senha = "root";
        $banco = "cardapio";

        $this->conexao = mysqli_connect($servidor, $usuario, $senha);
        $this->bd = mysqli_select_db($this->conexao, $banco);
    }

    public function __construct() 
    {
        $this -> connect();
    }

    public function tryLogin(string $tabela, string $email, string $senha) : int 
    {
        $sqlLogin = "SELECT * FROM " . $tabela . " WHERE email = '$email' AND senha = '$senha'";
        $resultadoLogin = mysqli_query($this->conexao, $sqlLogin);
        $row = mysqli_num_rows($resultadoLogin);
        
        if ($row == 1) {
            return true;
        } else {
            return false;
        }
    }

    public function authenticateAluno(string $email, string $password) : bool
    {
        $boolAluno = $this->tryLogin("ALUNO", $email, $password);

        if ($boolAluno == true) {
            $_SESSION['logado'] = 1;
            $sql = "SELECT adm FROM aluno WHERE email = '$email' AND senha = '$password'";
            $result = mysqli_query($this->conexao, $sql);
            $a = mysqli_fetch_row($result);
            $_SESSION["logado_adm"] = $a[0];
            $_SESSION["ID_aluno"] = $this->getIdAluno($email, $password);
            return true;
        } else {
            $_SESSION['logado'] = 0;
            $_SESSION['logado_adm'] = 0;
            return false;
        }
    }

    public function authenticateAdm(string $email, string $password) : bool
    {
        $boolAdm = $this->tryLogin("ADMINISTRADOR", $email, $password);

        if ($boolAdm == true) {
            $_SESSION["logado_adm"] = 1;
            $_SESSION["logado"] = 1;
            return true;
        } else {
            $_SESSION["logado_adm"] = 0;
            $_SESSION["logado"] = 0;
            return false;
        }
    }


    public function selectCursos()
    {
        $sql = "SELECT * FROM curso";
        $resultado = mysqli_query($this->conexao, $sql);
        
        $i=0;
        while ($r = mysqli_fetch_row($resultado)) {
            $cursos[$i] = $r;
            $i++;
        };

        return $cursos;
    }

    public function insertAluno(string $nome, string $apelido, string $idcurso, string $email, string $senha)
    {
        $sql = "INSERT INTO aluno(NOME, APELIDO, CURSO_IDCURSO, EMAIL, SENHA) VALUES ('$nome', '$apelido', $idcurso, '$email', '$senha')";
        mysqli_query($this->conexao, $sql);
    }

    public function deleteCardapio(string $id)
    {
        $sql = "DELETE FROM cardapio WHERE idcardapio = '$id'";
        mysqli_query($this->conexao, $sql);
    }

    public function selecNomeColunas(string $tabela)
    {
        $sql = "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '$tabela'";
        $resultado = mysqli_query($this->conexao, $sql);

        $i=0;
        while ($nomes = mysqli_fetch_row($resultado)) {
            $colunas[$i] = ucfirst($nomes[0]);
            $i++;
        };

        return $colunas;
    }

    public function selectAllWhere(string $tabela, string $id)
    {
        $sql = "SELECT * FROM " . $tabela . " WHERE id" . $tabela . " = '$id'";
        $resultado = mysqli_query($this->conexao, $sql);

        $i=0;
        while ($r = mysqli_fetch_array($resultado)) {
            $res = $r;
            $i++;
        };

        return $res;
    }

    public function updateCardapio(string $id, string $data, string $dia, string $cardapio, string $observacao, string $totalcurtida)
    {
        $sql = "UPDATE cardapio SET data = '$data', diasemana = '$dia', cardapio = '$cardapio', observacao = '$observacao', totalcurtida = '$totalcurtida' WHERE idcardapio = '$id'";
        mysqli_query($this->conexao, $sql);
    }

    public function getIdAluno(string $email, string $senha) : string
    {
        $sql = "SELECT idaluno FROM aluno WHERE email = '$email' AND senha = '$senha'";
        $resultado = mysqli_query($this->conexao, $sql);
        $r = mysqli_fetch_row($resultado);
        $r = $r[0];
        return $r;
    }
}