<?php
    include "../../conexao.php";
    include "../../SQL.php";
    include "../apoio/verificaSessao.php";

    if($_SESSION["logado_adm"] == 0)
        header("location: login-adm.php");
    
    $SQL = new SQL();
?>

<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="../../css/index.css">
        <title>Staff Excluir</title>
    </head>
    <body onload="pagSeleciona()">

        <div class="main-login" id="main-login">
            <form method="POST"> 
                <div class="right-login" id="right-login">
                    <div class="tabela">
                        <h1 style="color: white; font-size: x-large; transform: translate(0px, 65px)">SELECIONE O CARDÁPIO PARA ALTERAÇÃO:</h1>
                        <p style="color: white; font-size: small; transform: translate(0px, 70px)">(Ou altere diretamente na aba de cardapios)</p>
                        <?php
                            $tabela = "Cardapio";
                                
                            $sql = "SELECT * FROM $tabela ORDER BY data DESC";
                            $resultado = mysqli_query($conexao, $sql);
                                
                            $sql2 = "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME IN ('$tabela')";
                            $resultado2 = mysqli_query($conexao, $sql2);

                            $sql3 = "SELECT count(COLUMN_NAME) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME IN ('$tabela');";
                            $resultado3 = mysqli_query($conexao, $sql3);
                            $row = mysqli_fetch_array($resultado3);

                            echo "<div class='tabela'>";
                                echo "<table class='tabela2'>";

                                    echo "<tr>";
                                        while($coluna=mysqli_fetch_array($resultado2)){
                                            echo "<th>";
                                                echo $coluna['COLUMN_NAME'];
                                            echo "</th>";
                                        }

                                        echo "<th>";
                                            echo "SELECIONE";
                                        echo "</th>";
                                    echo "</tr>";

                                    while($linha=mysqli_fetch_array($resultado)){

                                        date_default_timezone_set('America/Sao_Paulo');
                                        
                                        $hoje = date('Y-m-d');
                             
                                        if ($hoje > $linha[1]) 
                                            $situacao = "expirado";
                                        else 
                                            $situacao = "ativo";

                                        echo "<tr class=" . $situacao . ">";
                                            for ($i=0; $i<$row[0]+1; $i++){
                                                if ($i == 6) {
                                                    echo "<td><input type='checkbox' name='checkbox' id='checkbox' value=" . $linha[3] . " onclick='checkboxPress()'></td>";
                                                } else {
                                                    echo "<td>".$linha[$i]."</td>";
                                                }
                                            }
                                        echo "</tr>";  
                                    }
                            
                                echo "</table>";
                                echo "<button type='submit' class='btn-login' name='btn-ok' id='btn-ok' style='width: 200px; cursor: no-drop;' disabled>CONFIRMAR</button>";
                                echo "<button type='submit' class='btn-login' name='btn-return' style='width: 200px'>RETORNAR</button>";
                            echo "</div>";

                            if (isset($_POST["btn-ok"])) {
                                $_SESSION["ID"] = $_POST["checkbox"];
                                var_dump($_SESSION);
                                header("location: adm_cardapio.php");
                            }

                            if (isset($_POST["btn-return"]))
                                header("location: adm.php")
                        ?>
                    </div>
                </div>
            </form>
        </div>

        

    </body>

    <script src="../../js/jquery/dist/jquery.min.js"></script>
    <script src="../../js/funcoes.js"></script>

</html>
